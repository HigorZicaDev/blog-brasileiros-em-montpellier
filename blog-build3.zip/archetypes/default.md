+++
title = '{{ replace .File.ContentBaseName "-" " " | title }}'
date = {{ .Date }}
draft = false
description = ""
image = ""
imageBig = ""
categories = ["general"]
authors = ["Higor Zica"]
avatar = "/images/avatar.webp"
published = false
+++
